function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6LTznlietOl":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

