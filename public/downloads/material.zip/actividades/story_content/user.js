function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6pS4Dg6GGax":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

